﻿namespace Inlämning4.Classes
{
    internal interface IStringDistance
    {
        float GetDistance(string s1, string s2);
    }
}
